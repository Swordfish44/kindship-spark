import { useState } from 'react';

type FormData = {
  fullName: string;
  organizationName?: string;
  email: string;
  phone?: string;
  campaignTitle: string;
  campaignDescription: string;
  fundingGoal?: number;
  socialLinks?: string;
};

export default function OrganizerOnboardingForm() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [onboardingUrl, setOnboardingUrl] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setOnboardingUrl(null);

    const form = new FormData(e.currentTarget as HTMLFormElement);
    const payload = {
      fullName: (form.get('fullName') as string || '').trim(),
      organizationName: (form.get('organizationName') as string || '').trim(),
      email: (form.get('email') as string || '').trim(),
      phone: (form.get('phone') as string || '').trim(),
      campaignTitle: (form.get('campaignTitle') as string || '').trim(),
      campaignDescription: (form.get('campaignDescription') as string || '').trim(),
      fundingGoal: Number(form.get('fundingGoal') || 0),
      socialLinks: (form.get('socialLinks') as string || '').trim(),
    };

    if (!payload.fullName || !payload.email || !payload.campaignTitle) {
      setError('Full name, email, and campaign title are required.');
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/organizers/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create organizer');
      setOnboardingUrl(data.onboardingLink || null);
    } catch (err: any) {
      setError(err.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{display: 'grid', gap: 12, maxWidth: 600}}>
      <label>
        Full Legal Name *
        <input name="fullName" required />
      </label>
      <label>
        Organization Name
        <input name="organizationName" />
      </label>
      <label>
        Email Address *
        <input name="email" type="email" required />
      </label>
      <label>
        Phone Number
        <input name="phone" type="tel" />
      </label>
      <label>
        Campaign Title *
        <input name="campaignTitle" required />
      </label>
      <label>
        Campaign Description
        <textarea name="campaignDescription" rows={4} />
      </label>
      <label>
        Funding Goal (optional, USD)
        <input name="fundingGoal" type="number" min={0} step={1} />
      </label>
      <label>
        Social Links (comma-separated)
        <input name="socialLinks" />
      </label>

      <button type="submit" disabled={loading}>
        {loading ? 'Creating…' : 'Create Organizer & Get Stripe Link'}
      </button>

      {error && <p style={{color:'crimson'}}>{error}</p>}
      {onboardingUrl && (
        <p>
          Stripe Onboarding Link: <a href={onboardingUrl} target="_blank">{onboardingUrl}</a>
        </p>
      )}
      <p style={{fontSize: 12, opacity: 0.7}}>
        Doc uploads required later: government ID, proof of address, business registration (if any), bank statement.
      </p>
    </form>
  );
}