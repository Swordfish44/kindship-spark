import { stripe } from '@/lib/stripe';
import db from '@/lib/db';
const _db = db?.default || db;

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { campaignSlug, amountCents = 500 } = req.body || {};
    if (!campaignSlug || amountCents < 100) {
      return res.status(400).json({ error: 'Missing campaignSlug or amount too low.' });
    }

    // Fetch campaign & organizer
    const { rows } = await _db.query(`
      SELECT c.id as campaign_id, o.id as organizer_id, o.stripe_account_id
      FROM campaigns c
      JOIN organizers o ON o.id = c.organizer_id
      WHERE c.slug = $1 AND c.status IN ('draft','live')
      LIMIT 1
    `, [campaignSlug]);

    if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });
    const { campaign_id, organizer_id, stripe_account_id } = rows[0];

    const bps = parseInt(process.env.PLATFORM_FEE_BPS || '800', 10);
    const platformFee = Math.floor((amountCents * bps) / 10000);

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_intent_data: {
        application_fee_amount: platformFee,
        transfer_data: { destination: stripe_account_id },
      },
      line_items: [{
        quantity: 1,
        price_data: {
          currency: process.env.DEFAULT_CURRENCY || 'usd',
          unit_amount: amountCents,
          product_data: { name: `Donation to ${campaignSlug}` },
        }
      }],
      success_url: (process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000') + '/?donated=1',
      cancel_url: (process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000') + '/?canceled=1',
      metadata: { campaign_id, organizer_id }
    });

    return res.status(200).json({ checkoutUrl: session.url });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message || 'Internal Server Error' });
  }
}