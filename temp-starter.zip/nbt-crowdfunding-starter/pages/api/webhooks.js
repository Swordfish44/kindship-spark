import { stripe } from '@/lib/stripe';
import db from '@/lib/db';
const _db = db?.default || db;

export const config = {
  api: {
    bodyParser: false, // Stripe needs raw body
  },
};

function buffer(readable) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    readable.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
    readable.on('end', () => resolve(Buffer.concat(chunks)));
    readable.on('error', reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end('Method Not Allowed');
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let event;

  try {
    const buf = await buffer(req);
    event = stripe.webhooks.constructEvent(buf, sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        // Retrieve the session & payment intent to record donation
        const session = event.data.object;
        const pi = session.payment_intent && typeof session.payment_intent === 'string'
          ? await stripe.paymentIntents.retrieve(session.payment_intent)
          : session.payment_intent;

        const amount = pi?.amount || session.amount_total || 0;
        const currency = pi?.currency || session.currency || 'usd';
        const platformFee = pi?.application_fee_amount || 0;
        const netToOrganizer = Math.max(0, amount - platformFee);

        const campaignId = session.metadata?.campaign_id;
        const donorId = null; // TODO: attach authenticated donor if you add auth

        await _db.query(`
          INSERT INTO donations (campaign_id, donor_id, amount_cents, currency, stripe_payment_intent_id, platform_fee_cents, net_to_organizer_cents)
          VALUES ($1, $2, $3, $4, $5, $6, $7)
        `, [campaignId, donorId, amount, currency, typeof session.payment_intent === 'string' ? session.payment_intent : null, platformFee, netToOrganizer]);

        break;
      }
      case 'payout.paid': {
        const payout = event.data.object;
        // Optional: persist payouts if you pull which organizer by account_id
        break;
      }
      default:
        // console.log('Unhandled event type:', event.type);
        break;
    }
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook handling error:', err);
    res.status(500).json({ error: 'Webhook handler failed' });
  }
}