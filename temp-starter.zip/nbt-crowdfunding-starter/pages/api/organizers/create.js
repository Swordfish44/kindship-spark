import { stripe } from '@/lib/stripe';
import db from '@/lib/db'; // CommonJS export; use default import shim
const _db = db?.default || db;

function bpsToAmount(amountCents, bps) {
  return Math.floor((amountCents * bps) / 10000);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { fullName, organizationName, email, phone, campaignTitle, campaignDescription, fundingGoal = 0 } = req.body || {};
    if (!fullName || !email || !campaignTitle) {
      return res.status(400).json({ error: 'Missing required fields.' });
    }

    // Upsert user
    const userResult = await _db.query(`
      INSERT INTO users (email, full_name, phone, role)
      VALUES ($1, $2, $3, 'organizer')
      ON CONFLICT (email) DO UPDATE SET full_name = EXCLUDED.full_name, phone = EXCLUDED.phone
      RETURNING id
    `, [email, fullName, phone || null]);
    const userId = userResult.rows[0].id;

    // Create Stripe Connect Express account
    const account = await stripe.accounts.create({
      type: 'express',
      country: 'US',
      email,
      business_type: 'individual',
      capabilities: {
        transfers: { requested: true },
        card_payments: { requested: true },
      },
      metadata: { user_id: userId, project: 'NBT Crowdfunding' },
    });

    // Create organizer row
    const orgResult = await _db.query(`
      INSERT INTO organizers (user_id, organization_name, stripe_account_id, onboarding_completed, kyc_status)
      VALUES ($1, $2, $3, false, 'pending')
      RETURNING id
    `, [userId, organizationName || null, account.id]);
    const organizerId = orgResult.rows[0].id;

    // Create a slug from campaign title
    const slug = campaignTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    // Create initial campaign in 'draft'
    await _db.query(`
      INSERT INTO campaigns (organizer_id, title, slug, description, goal_cents, status)
      VALUES ($1, $2, $3, $4, $5, 'draft')
    `, [organizerId, campaignTitle, slug, campaignDescription || null, Math.max(0, Number(fundingGoal) * 100)]);

    // Create an account onboarding link
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
    const accountLink = await stripe.accountLinks.create({
      account: account.id,
      refresh_url: baseUrl + '/organizer/onboard',
      return_url: baseUrl + '/organizer/onboard?done=true',
      type: 'account_onboarding',
    });

    return res.status(200).json({ organizerId, stripeAccountId: account.id, onboardingLink: accountLink.url, slug });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message || 'Internal Server Error' });
  }
}