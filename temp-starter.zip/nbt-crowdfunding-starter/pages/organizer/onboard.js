import OrganizerOnboardingForm from '@/components/OrganizerOnboardingForm';

export default function OnboardPage() {
  return (
    <main style={{padding: 24, fontFamily: 'system-ui, Arial'}}>
      <h1>Organizer Onboarding</h1>
      <OrganizerOnboardingForm />
    </main>
  );
}