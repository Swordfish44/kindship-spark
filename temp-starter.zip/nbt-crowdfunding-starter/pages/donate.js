import { useState } from 'react';

export default function DonateQuick() {
  const [slug, setSlug] = useState('');
  const [amount, setAmount] = useState(1000);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const go = async () => {
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/checkout/create', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ campaignSlug: slug, amountCents: Number(amount) })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      window.location.href = data.checkoutUrl;
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <main style={{padding:24, fontFamily:'system-ui, Arial'}}>
      <h1>Quick Donate (Test)</h1>
      <input placeholder="campaign-slug" value={slug} onChange={e=>setSlug(e.target.value)} />
      <input type="number" min={100} step={50} value={amount} onChange={e=>setAmount(e.target.value)} />
      <button onClick={go} disabled={loading}>{loading ? '…' : 'Donate'}</button>
      {error && <p style={{color:'crimson'}}>{error}</p>}
    </main>
  );
}