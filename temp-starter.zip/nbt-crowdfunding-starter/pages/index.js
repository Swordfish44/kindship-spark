export default function Home() {
  return (
    <main style={{padding: 24, fontFamily: 'system-ui, Arial'}}>
      <h1>NBT Crowdfunding Starter</h1>
      <p>Donations/Rewards • Keep-what-you-raise • Stripe Connect (Express)</p>
      <ol>
        <li>Create your database and run <code>schema.sql</code></li>
        <li>Copy <code>.env.example</code> to <code>.env.local</code> and fill values</li>
        <li><code>npm install</code> then <code>npm run dev</code></li>
      </ol>
      <p>
        Organizer? Go to <a href="/organizer/onboard">/organizer/onboard</a> to start onboarding.
      </p>
    </main>
  );
}