# NBT Crowdfunding Starter (Donations/Rewards)

**Stack:** Next.js + Stripe Connect (Express) + Postgres  
**Model:** Keep-what-you-raise, 8% platform fee (configurable via `PLATFORM_FEE_BPS`).

## Quick Start

1) Create DB & run schema
```bash
psql "$DATABASE_URL" -f schema.sql
```

2) Copy env
```bash
cp .env.example .env.local
# Fill STRIPE_* and DATABASE_URL
```

3) Install & run
```bash
npm install
npm run dev
```

4) Stripe Connect
- This boilerplate creates an **Express** account for each organizer and returns an onboarding link.
- Donations use **Stripe Checkout** with `application_fee_amount` and `transfer_data.destination` to route funds to the organizer.

## API Routes

- `POST /api/organizers/create` → Creates user+organizer, creates Stripe Connect account, returns onboarding link
- `POST /api/checkout/create` → Creates a Checkout Session for a donation (with 8% platform fee)
- `POST /api/webhooks` → Handles Stripe events to persist donations/payouts

## Pages

- `/` → Simple home page with quick instructions
- `/organizer/onboard` → Organizer onboarding form

## Notes
- Document uploads: you likely want S3/GCS. This starter stores only metadata placeholders.
- Security: add auth (NextAuth, etc.), CSRF protection, and production-grade validations before going live.