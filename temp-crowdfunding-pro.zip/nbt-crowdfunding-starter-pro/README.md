# NBT Crowdfunding Starter – PRO
Stack: Next.js + TypeScript + Zod + Stripe Connect + Postgres + QStash + S3
