export default function Home() {
  return (
    <main style={{padding: 24, fontFamily: 'system-ui, Arial'}}>
      <h1>NBT Crowdfunding Starter – PRO</h1>
      <p>Next.js • TypeScript • Zod • Stripe Connect • Postgres • QStash • S3</p>
    </main>
  );
}