import type { NextApiRequest, NextApiResponse } from 'next';
import { stripe } from '@/lib/stripe';
import { query } from '@/lib/db';
import { CheckoutCreateSchema } from '@/lib/validation';
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const parsed = CheckoutCreateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { campaignSlug, amountCents } = parsed.data;
  const { rows } = await query<{ campaign_id: string; organizer_id: string; stripe_account_id: string }>(
    "SELECT c.id as campaign_id, o.id as organizer_id, o.stripe_account_id FROM campaigns c JOIN organizers o ON o.id = c.organizer_id WHERE c.slug = $1 AND c.status IN ('draft','live') LIMIT 1",
    [campaignSlug]
  );
  if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });
  const { campaign_id, organizer_id, stripe_account_id } = rows[0];
  const bps = parseInt(process.env.PLATFORM_FEE_BPS || '800', 10);
  const platformFee = Math.floor((amountCents * bps) / 10000);
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_intent_data: { application_fee_amount: platformFee, transfer_data: { destination: stripe_account_id } },
    line_items: [{ quantity: 1, price_data: { currency: process.env.DEFAULT_CURRENCY || 'usd', unit_amount: amountCents, product_data: { name: `Donation to ${campaignSlug}` } } }],
    success_url: (process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000') + '/?donated=1',
    cancel_url: (process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000') + '/?canceled=1',
    metadata: { campaign_id, organizer_id }
  });
  return res.status(200).json({ checkoutUrl: session.url });
}