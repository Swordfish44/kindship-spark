import type { NextApiRequest, NextApiResponse } from 'next';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
const s3 = new S3Client({ region: process.env.S3_REGION });
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { fileName, contentType, prefix = 'uploads' } = req.body || {};
  if (!fileName || !contentType) return res.status(400).json({ error: 'fileName and contentType are required' });
  const bucket = process.env.S3_BUCKET;
  if (!bucket) return res.status(500).json({ error: 'S3_BUCKET not configured' });
  const key = `${prefix}/${Date.now()}-${fileName}`;
  const command = new PutObjectCommand({ Bucket: bucket, Key: key, ContentType: contentType });
  const url = await getSignedUrl(s3, command, { expiresIn: 300 });
  const publicUrl = `https://${bucket}.s3.${process.env.S3_REGION}.amazonaws.com/${key}`;
  return res.status(200).json({ url, key, publicUrl });
}