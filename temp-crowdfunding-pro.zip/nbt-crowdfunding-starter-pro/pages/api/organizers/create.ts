import type { NextApiRequest, NextApiResponse } from 'next';
import { stripe } from '@/lib/stripe';
import { query } from '@/lib/db';
import { OrganizerCreateSchema } from '@/lib/validation';
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const parsed = OrganizerCreateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { fullName, organizationName, email, phone, campaignTitle, campaignDescription, fundingGoal = 0 } = parsed.data;
  const userResult = await query<{id: string}>(
    "INSERT INTO users (email, full_name, phone, role) VALUES ($1,$2,$3,'organizer') ON CONFLICT (email) DO UPDATE SET full_name=EXCLUDED.full_name, phone=EXCLUDED.phone RETURNING id",
    [email, fullName, phone || null]
  );
  const userId = userResult.rows[0].id;
  const account = await stripe.accounts.create({
    type: 'express', country: 'US', email, business_type: 'individual',
    capabilities: { transfers: { requested: true }, card_payments: { requested: true } },
    metadata: { user_id: userId, project: 'NBT Crowdfunding' },
  });
  const org = await query<{id: string}>(
    "INSERT INTO organizers (user_id, organization_name, stripe_account_id, onboarding_completed, kyc_status) VALUES ($1,$2,$3,false,'pending') RETURNING id",
    [userId, organizationName || null, account.id]
  );
  const organizerId = org.rows[0].id;
  const slug = campaignTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  await query(
    "INSERT INTO campaigns (organizer_id, title, slug, description, goal_cents, status) VALUES ($1,$2,$3,$4,$5,'draft')",
    [organizerId, campaignTitle, slug, campaignDescription || null, Math.max(0, Number(fundingGoal) * 100)]
  );
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const accountLink = await stripe.accountLinks.create({
    account: account.id, refresh_url: baseUrl + '/organizer/onboard', return_url: baseUrl + '/organizer/onboard?done=true', type: 'account_onboarding',
  });
  return res.status(200).json({ organizerId, stripeAccountId: account.id, onboardingLink: accountLink.url, slug });
}