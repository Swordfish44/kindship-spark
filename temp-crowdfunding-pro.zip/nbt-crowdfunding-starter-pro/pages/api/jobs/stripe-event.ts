import type { NextApiRequest, NextApiResponse } from 'next';
import { Receiver } from '@upstash/qstash';
import { stripe } from '@/lib/stripe';
import { query } from '@/lib/db';
const receiver = new Receiver({
  currentSigningKey: process.env.QSTASH_CURRENT_SIGNING_KEY || '',
  nextSigningKey: process.env.QSTASH_NEXT_SIGNING_KEY || '',
});
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const signature = req.headers['upstash-signature'] as string | undefined;
  if (!signature) return res.status(400).json({ error: 'Missing Upstash signature' });
  const body = JSON.stringify(req.body);
  const valid = await receiver.verify({ signature, body, url: (process.env.NEXT_PUBLIC_BASE_URL || '') + '/api/jobs/stripe-event' });
  if (!valid) return res.status(401).json({ error: 'Invalid signature' });
  const { type, data } = req.body as any;
  if (type === 'checkout.session.completed') {
    const session = data.object;
    let amount = session.amount_total || 0;
    let currency = session.currency || 'usd';
    let payment_intent_id = typeof session.payment_intent === 'string' ? session.payment_intent : null;
    if (!amount || !currency || !payment_intent_id) {
      if (typeof session.payment_intent === 'string') {
        const pi = await stripe.paymentIntents.retrieve(session.payment_intent);
        amount = pi.amount; currency = pi.currency; payment_intent_id = pi.id;
      }
    }
    const platformFee = session.application_fee_amount || 0;
    const netToOrganizer = Math.max(0, Number(amount) - Number(platformFee));
    const campaignId = session.metadata?.campaign_id || null;
    if (campaignId && payment_intent_id) {
      await query(
        "INSERT INTO donations (campaign_id, donor_id, amount_cents, currency, stripe_payment_intent_id, platform_fee_cents, net_to_organizer_cents) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (stripe_payment_intent_id) DO NOTHING",
        [campaignId, null, amount, currency, payment_intent_id, platformFee || 0, netToOrganizer]
      );
    }
  }
  return res.status(200).json({ ok: true });
}