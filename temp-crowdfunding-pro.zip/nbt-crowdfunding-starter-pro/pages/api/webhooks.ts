import type { NextApiRequest, NextApiResponse } from 'next';
import getRawBody from 'raw-body';
import { stripe } from '@/lib/stripe';
import { Client as QStashClient } from '@upstash/qstash';
export const config = { api: { bodyParser: false } };
const qstash = process.env.QSTASH_TOKEN ? new QStashClient({ token: process.env.QSTASH_TOKEN }) : null;
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end('Method Not Allowed');
  const sig = req.headers['stripe-signature'] as string | undefined;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!sig || !webhookSecret) return res.status(400).send('Missing Stripe signature or secret');
  const buf = await getRawBody(req);
  const event = stripe.webhooks.constructEvent(buf, sig, webhookSecret);
  if (!qstash) return res.status(500).send('QStash not configured');
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  await qstash.publishJSON({ url: `${baseUrl}/api/jobs/stripe-event`, body: { type: event.type, data: event.data } });
  return res.status(200).json({ received: true });
}