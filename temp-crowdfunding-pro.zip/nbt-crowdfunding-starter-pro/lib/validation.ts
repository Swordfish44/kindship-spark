import { z } from 'zod';
export const OrganizerCreateSchema = z.object({
  fullName: z.string().min(1),
  organizationName: z.string().optional(),
  email: z.string().email(),
  phone: z.string().optional(),
  campaignTitle: z.string().min(1),
  campaignDescription: z.string().optional(),
  fundingGoal: z.number().min(0).optional(),
  socialLinks: z.string().optional(),
});
export const CheckoutCreateSchema = z.object({
  campaignSlug: z.string().min(1),
  amountCents: z.number().int().min(100),
});
export type OrganizerCreateInput = z.infer<typeof OrganizerCreateSchema>;
export type CheckoutCreateInput = z.infer<typeof CheckoutCreateSchema>;