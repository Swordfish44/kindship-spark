import { Pool } from 'pg';
const connectionString = process.env.DATABASE_URL;
if (!connectionString) console.warn('DATABASE_URL not set.');
const pool = new Pool({ connectionString });
export async function query<T = any>(text: string, params?: any[]): Promise<{ rows: T[] }> {
  return pool.query(text, params);
}
export { pool };